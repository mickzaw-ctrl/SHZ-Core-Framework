import { useState, useEffect, useRef } from 'react';
import { SHZEngine, SHZState } from './lib/shz-engine';
import { NetworkVisualizer } from './components/NetworkVisualizer';
import { StatsCharts } from './components/StatsCharts';
import { Controls } from './components/Controls';
import { Activity, Zap } from 'lucide-react';

function App() {
  const [params, setParams] = useState({
    numNodes: 200,
    beta: 3.0,
    maxDegreeLimit: 30,
  });
  const [isRunning, setIsRunning] = useState(false);
  const [state, setState] = useState<SHZState | null>(null);
  
  const engineRef = useRef<SHZEngine | null>(null);
  const requestRef = useRef<number | null>(null);

  // Initialize or reset engine when parameters change
  useEffect(() => {
    const engine = new SHZEngine(params.numNodes, params.beta, params.maxDegreeLimit);
    engineRef.current = engine;
    setState(engine.getState());
  }, [params]);

  const simulate = () => {
    if (engineRef.current && isRunning) {
      // Run a batch of steps to maintain performance
      engineRef.current.runBatch(500, 100);
      setState(engineRef.current.getState());
    }
    requestRef.current = requestAnimationFrame(() => simulate());
  };

  useEffect(() => {
    if (isRunning) {
      requestRef.current = requestAnimationFrame(simulate);
    } else {
      if (requestRef.current !== null) cancelAnimationFrame(requestRef.current);
    }
    return () => {
      if (requestRef.current !== null) cancelAnimationFrame(requestRef.current);
    };
  }, [isRunning]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 p-4 md:p-8 font-sans">
      {/* Header */}
      <header className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
        <div>
          <div className="flex items-center gap-2 text-blue-400 mb-2">
            <Zap size={20} fill="currentColor" />
            <span className="text-xs font-bold uppercase tracking-widest">Quantum Network Lab</span>
          </div>
          <h1 className="text-4xl font-extrabold tracking-tight text-white">
            SHZ <span className="text-blue-500">Engine</span>
          </h1>
          <p className="text-slate-400 mt-2 max-w-2xl">
            Simulating spacetime geometry evolution based on the SHZ axiom, 
            where nodes evolve toward a target degree of <span className="text-red-400 font-mono font-bold">k=8</span>.
          </p>
        </div>
        
        <div className="flex items-center gap-4 bg-slate-900 p-3 rounded-xl border border-slate-800">
          <div className="flex items-center gap-2">
            <Activity size={18} className={isRunning ? 'text-green-400 animate-pulse' : 'text-slate-500'} />
            <span className="text-sm font-mono">
              Step: {state?.currentStep.toLocaleString() || 0}
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Column: Controls */}
        <div className="lg:col-span-3">
          <Controls 
            params={params} 
            setParams={setParams} 
            isRunning={isRunning} 
            setBisRunning={setIsRunning} 
          />
        </div>

        {/* Right Column: Visuals */}
        <div className="lg:col-span-9 space-y-8">
          {/* Network Visualization */}
          <div className="h-[600px]">
            {state && <NetworkVisualizer state={state} />}
          </div>

          {/* Stats Charts */}
          {state && <StatsCharts state={state} />}
        </div>
      </main>

      <footer className="max-w-7xl mx-auto mt-12 pt-8 border-t border-slate-800 text-center text-slate-500 text-sm">
        <p>© 2026 Spacetime Topology Simulation · Powered by Metropolis-Hastings Algorithm</p>
      </footer>
    </div>
  );
}

export default App;
