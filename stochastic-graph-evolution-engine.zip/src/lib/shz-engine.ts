export interface SHZState {
  adjList: Set<number>[];
  degrees: number[];
  degreeDistribution: number[];
  historyAvgDegree: { step: number; value: number }[];
  currentStep: number;
}

export class SHZEngine {
  numNodes: number;
  beta: number;
  gamma: number = 1.0;
  maxDegreeLimit: number;

  adjList: Set<number>[];
  degrees: number[];
  degreeDistribution: number[];
  historyAvgDegree: { step: number; value: number }[];
  currentStep: number = 0;

  constructor(numNodes: number, beta: number = 1.5, maxDegreeLimit: number = 30) {
    this.numNodes = numNodes;
    this.beta = beta;
    this.maxDegreeLimit = maxDegreeLimit;

    this.adjList = Array.from({ length: numNodes }, () => new Set<number>());
    this.degrees = new Array(numNodes).fill(0);
    this.degreeDistribution = new Array(maxDegreeLimit + 1).fill(0);
    this.degreeDistribution[0] = numNodes;
    this.historyAvgDegree = [];
  }

  private updateDegree(node: number, delta: number): boolean {
    const oldDeg = this.degrees[node];
    const newDeg = oldDeg + delta;

    if (newDeg > this.maxDegreeLimit || newDeg < 0) {
      return false;
    }

    this.degrees[node] = newDeg;
    this.degreeDistribution[oldDeg]--;
    this.degreeDistribution[newDeg]++;
    return true;
  }

  private getNodeEnergyContribution(degree: number): number {
    return -this.gamma * Math.pow(degree - 8, 2);
  }

  proposeAndEvaluateMove(): void {
    const u = Math.floor(Math.random() * this.numNodes);
    const v = Math.floor(Math.random() * this.numNodes);
    if (u === v) return;

    const edgeExists = this.adjList[u].has(v);
    const delta = edgeExists ? -1 : 1;

    const degU = this.degrees[u];
    const degV = this.degrees[v];

    if (!edgeExists && (degU >= this.maxDegreeLimit || degV >= this.maxDegreeLimit)) {
      return;
    }

    const oldEnergy = this.getNodeEnergyContribution(degU) + this.getNodeEnergyContribution(degV);
    const newEnergy = this.getNodeEnergyContribution(degU + delta) + this.getNodeEnergyContribution(degV + delta);
    const deltaE = newEnergy - oldEnergy;

    if (deltaE > 0 || Math.random() < Math.exp(this.beta * deltaE)) {
      if (edgeExists) {
        this.adjList[u].delete(v);
        this.adjList[v].delete(u);
      } else {
        this.adjList[u].add(v);
        this.adjList[v].add(u);
      }

      this.updateDegree(u, delta);
      this.updateDegree(v, delta);
    }
  }

  runBatch(steps: number, sampleInterval: number): void {
    for (let i = 0; i < steps; i++) {
      this.proposeAndEvaluateMove();
      this.currentStep++;

      if (this.currentStep % sampleInterval === 0) {
        const avgK = this.degrees.reduce((a, b) => a + b, 0) / this.numNodes;
        this.historyAvgDegree.push({ step: this.currentStep, value: avgK });
      }
    }
  }

  getState(): SHZState {
    return {
      adjList: this.adjList.map(set => new Set(set)),
      degrees: [...this.degrees],
      degreeDistribution: [...this.degreeDistribution],
      historyAvgDegree: [...this.historyAvgDegree],
      currentStep: this.currentStep,
    };
  }
}
