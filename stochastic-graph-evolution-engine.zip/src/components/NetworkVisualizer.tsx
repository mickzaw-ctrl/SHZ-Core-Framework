import React, { useEffect, useRef } from 'react';
import { SHZState } from '../lib/shz-engine';

interface NetworkVisualizerProps {
  state: SHZState;
}

export const NetworkVisualizer: React.FC<NetworkVisualizerProps> = ({ state }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const nodesRef = useRef<{ x: number; y: number; vx: number; vy: number }[]>([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Initialize nodes if they don't exist or count changed
    if (nodesRef.current.length !== state.degrees.length) {
      nodesRef.current = state.degrees.map(() => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: 0,
        vy: 0,
      }));
    }

    let animationFrameId: number;

    const simulate = () => {
      const nodes = nodesRef.current;
      const numNodes = nodes.length;
      const k = Math.sqrt((canvas.width * canvas.height) / numNodes); // Ideal distance
      const repulsion = 100;
      const attraction = 0.05;
      const damping = 0.9;

      // Repulsion
      for (let i = 0; i < numNodes; i++) {
        for (let j = i + 1; j < numNodes; j++) {
          const dx = nodes[i].x - nodes[j].x;
          const dy = nodes[i].y - nodes[j].y;
          const distSq = dx * dx + dy * dy + 0.01;
          const force = repulsion / distSq;
          const fx = (dx / Math.sqrt(distSq)) * force;
          const fy = (dy / Math.sqrt(distSq)) * force;
          nodes[i].vx += fx;
          nodes[i].vy += fy;
          nodes[j].vx -= fx;
          nodes[j].vy -= fy;
        }
      }

      // Attraction (Edges)
      state.adjList.forEach((neighbors, i) => {
        neighbors.forEach(j => {
          if (i < j) {
            const dx = nodes[i].x - nodes[j].x;
            const dy = nodes[i].y - nodes[j].y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const force = attraction * (dist - k);
            const fx = (dx / dist) * force;
            const fy = (dy / dist) * force;
            nodes[i].vx -= fx;
            nodes[i].vy -= fy;
            nodes[j].vx += fx;
            nodes[j].vy += fy;
          }
        });
      });

      // Center gravity
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      nodes.forEach(node => {
        node.vx += (centerX - node.x) * 0.001;
        node.vy += (centerY - node.y) * 0.001;

        node.x += node.vx;
        node.y += node.vy;
        node.vx *= damping;
        node.vy *= damping;

        // Boundary
        if (node.x < 0) node.x = 0;
        if (node.x > canvas.width) node.x = canvas.width;
        if (node.y < 0) node.y = 0;
        if (node.y > canvas.height) node.y = canvas.height;
      });

      // Draw
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Edges
      ctx.strokeStyle = 'rgba(100, 150, 255, 0.2)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      state.adjList.forEach((neighbors, i) => {
        neighbors.forEach(j => {
          if (i < j) {
            ctx.moveTo(nodes[i].x, nodes[i].y);
            ctx.lineTo(nodes[j].x, nodes[j].y);
          }
        });
      });
      ctx.stroke();

      // Nodes
      nodes.forEach((node, i) => {
        const degree = state.degrees[i];
        const size = Math.max(2, Math.min(6, degree / 2));
        const opacity = Math.max(0.3, Math.min(1, degree / 8));
        
        ctx.fillStyle = degree === 8 ? '#ef4444' : `rgba(100, 200, 255, ${opacity})`;
        ctx.beginPath();
        ctx.arc(node.x, node.y, size, 0, Math.PI * 2);
        ctx.fill();
      });

      animationFrameId = requestAnimationFrame(simulate);
    };

    simulate();

    return () => cancelAnimationFrame(animationFrameId);
  }, [state]);

  return (
    <div className="relative w-full h-full bg-slate-950 rounded-xl overflow-hidden border border-slate-800 shadow-inner">
      <canvas 
        ref={canvasRef} 
        width={800} 
        height={600} 
        className="w-full h-full object-contain"
      />
      <div className="absolute top-4 left-4 pointer-events-none">
        <div className="bg-slate-900/80 backdrop-blur-sm px-3 py-1 rounded text-xs text-slate-400 border border-slate-700">
          Network Topology (Red = Degree 8)
        </div>
      </div>
    </div>
  );
};
