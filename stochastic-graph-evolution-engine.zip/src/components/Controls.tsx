import React from 'react';
import { Settings2 } from 'lucide-react';

interface ControlsProps {
  params: {
    numNodes: number;
    beta: number;
    maxDegreeLimit: number;
  };
  setParams: (params: any) => void;
  isRunning: boolean;
  setBisRunning: (val: boolean) => void;
}

export const Controls: React.FC<ControlsProps> = ({ params, setParams, isRunning, setBisRunning }) => {
  const handleChange = (key: string, value: number) => {
    setParams({ ...params, [key]: value });
  };

  return (
    <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-sm h-full">
      <div className="flex items-center gap-2 mb-6 text-slate-200 font-semibold">
        <Settings2 size={20} />
        <h2>Simulation Parameters</h2>
      </div>
      
      <div className="space-y-6">
        <div>
          <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">
            Number of Nodes: {params.numNodes}
          </label>
          <input 
            type="range" 
            min="20" 
            max="500" 
            step="10"
            value={params.numNodes}
            onChange={(e) => handleChange('numNodes', parseInt(e.target.value))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">
            Beta (Coupling): {params.beta.toFixed(2)}
          </label>
          <input 
            type="range" 
            min="0.1" 
            max="10" 
            step="0.1"
            value={params.beta}
            onChange={(e) => handleChange('beta', parseFloat(e.target.value))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-400 uppercase tracking-wider mb-2">
            Max Degree Limit: {params.maxDegreeLimit}
          </label>
          <input 
            type="range" 
            min="10" 
            max="60" 
            step="1"
            value={params.maxDegreeLimit}
            onChange={(e) => handleChange('maxDegreeLimit', parseInt(e.target.value))}
            className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
        </div>

        <div className="pt-4">
          <button 
            onClick={() => setBisRunning(!isRunning)}
            className={`w-full py-3 rounded-lg font-bold transition-all ${
              isRunning 
                ? 'bg-red-500/10 text-red-500 border border-red-500/50 hover:bg-red-500/20' 
                : 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-900/20'
            }`}
          >
            {isRunning ? 'Pause Simulation' : 'Start Simulation'}
          </button>
        </div>
      </div>
    </div>
  );
};
