import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  LineChart, Line, ReferenceLine 
} from 'recharts';
import { SHZState } from '../lib/shz-engine';

interface StatsChartsProps {
  state: SHZState;
}

export const StatsCharts: React.FC<StatsChartsProps> = ({ state }) => {
  const distributionData = state.degreeDistribution.map((count, k) => ({
    k,
    count,
  }));

  const historyData = state.historyAvgDegree;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Degree Distribution */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-sm">
        <h3 className="text-slate-200 font-medium mb-4">Degree Distribution</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distributionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis 
                dataKey="k" 
                stroke="#94a3b8" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false}
                label={{ value: 'Degree (k)', position: 'insideBottom', offset: -5, fill: '#94a3b8', fontSize: 12 }}
              />
              <YAxis 
                stroke="#94a3b8" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false}
                label={{ value: 'Nodes', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 12 }}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f1f5f9' }} 
                itemStyle={{ color: '#60a5fa' }}
              />
              <ReferenceLine x={8} stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'top', value: 'SHZ (k=8)', fill: '#ef4444', fontSize: 10 }} />
              <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Evolution of Average Degree */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-sm">
        <h3 className="text-slate-200 font-medium mb-4">Evolution of Spacetime Geometry</h3>
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={historyData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis 
                dataKey="step" 
                stroke="#94a3b8" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false}
                label={{ value: 'Simulation Step', position: 'insideBottom', offset: -5, fill: '#94a3b8', fontSize: 12 }}
              />
              <YAxis 
                domain={[0, 'auto']}
                stroke="#94a3b8" 
                fontSize={12} 
                tickLine={false} 
                axisLine={false}
                label={{ value: 'Avg Degree <k>', angle: -90, position: 'insideLeft', fill: '#94a3b8', fontSize: 12 }}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#f1f5f9' }} 
                itemStyle={{ color: '#f97316' }}
              />
              <ReferenceLine y={8} stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'right', value: '8', fill: '#ef4444', fontSize: 10 }} />
              <Line type="monotone" dataKey="value" stroke="#f97316" strokeWidth={2} dot={false} animationDuration={300} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
